//
//  selectViewController.swift
//  falldown
//
//  Created by Cong on 7/10/17.
//  Copyright © 2017 Microsoft. All rights reserved.
//

import UIKit

class selectViewController: UIViewController {

    var userID:String?
    var table : MSTable?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let client = MSClient(applicationURLString: "https://falldown.azurewebsites.net")
        table = client.table(withName: "locationData")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func needHelpButtonTapped(_ sender: Any) {
        userID = UserDefaults.standard.string(forKey: "loggedInID")
        let newUser = ["id":userID]
        self.table!.insert(newUser)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
