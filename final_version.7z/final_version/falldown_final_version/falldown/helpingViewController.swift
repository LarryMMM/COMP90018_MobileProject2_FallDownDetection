//
//  helpingViewController.swift
//  falldown
//
//  Created by Cong on 8/10/17.
//  Copyright © 2017 Microsoft. All rights reserved.
//

import UIKit
import UserNotifications
import AVFoundation
class helpingViewController: UIViewController {

    @IBOutlet weak var watchIDTextfield: UILabel!
    @IBOutlet weak var userNameDisplay: UILabel!
    @IBOutlet weak var userAgeDisplay: UILabel!
    @IBOutlet weak var userPhoneDisplay: UILabel!
    
    var watchID:String?
    var userTable:MSTable?
    var locationTable:MSTable?
    var latitude:String?
    var longitude:String?
    var qbc=0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let client = MSClient(applicationURLString: "https://falldown.azurewebsites.net")
        userTable = client.table(withName: "userData")
        locationTable = client.table(withName: "locationData")
        
        //keep active
        var timer = Timer.scheduledTimer(timeInterval: 20, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool){
        watchIDTextfield.text = UserDefaults.standard.string(forKey: "watchID")
        watchID = UserDefaults.standard.string(forKey: "watchID")
        
        let predicate = NSPredicate(format:"id == %@", watchID!)
        userTable!.read(with: predicate) { (result, error) in
            if let err = error {
                print("ERROR ", err)
            } else if let items = result?.items {
                for item in items {
                    self.userNameDisplay.text = item["name"] as? String
                    self.userAgeDisplay.text = item["Age"] as? String
                    self.userPhoneDisplay.text = item["phone"] as? String
                }
            }
        }
        
    }
    
    @objc func update(){
        watchID = UserDefaults.standard.string(forKey: "watchID")
        let predicate = NSPredicate(format:"id == %@", watchID!)
        
        locationTable!.read(with: predicate) { (result, error) in
            if let err = error {
                print("ERROR ", err)
            } else if let items = result?.items {
                for item in items {
                    if(item["latitude"] != nil && self.qbc==0){
                        self.qbc=1
                        print(item["latitude"])
                        let latitude = item["latitude"]
                        print(item["longitude"])
                        let longitude = item["longitude"]
                  
                        UserDefaults.standard.set(latitude, forKey: "latitude")
                        UserDefaults.standard.set(longitude, forKey: "longitude")
                        UserDefaults.standard.synchronize()
                        self.alarmNotification()
                        self.performSegue(withIdentifier: "showmapView", sender: self)
                    }
                    
                }
            }
        }        
    }
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    func  createAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        //create one button
        alert.addAction(UIAlertAction(title: "Yes",style: UIAlertActionStyle.cancel,handler:{(action)in
            alert.dismiss(animated: true, completion: nil)
        }))
        //create another button
        alert.addAction(UIAlertAction(title: "No",style: UIAlertActionStyle.destructive,handler:{(action)in
            alert.dismiss(animated: true, completion: nil)
        }))
        self.present(alert, animated: true, completion: nil)
        let when = DispatchTime.now() + 30 //30 seconds for waiting
        DispatchQueue.main.asyncAfter(deadline: when){
            alert.dismiss(animated: true, completion: nil)
        }
    }
    
    func alarmNotification() {
        if #available(iOS 10.0, *) {
            let content = UNMutableNotificationContent()
            content.title = "Fall Down Detected!"
            //content.subtitle = "at location \(NSString .localizedStringWithFormat("%.4f", self.cordsX),NSString .localizedStringWithFormat("%.4f", self.cordsY))"
            content.body = "User need help!"
            content.badge = 1
            content.sound = UNNotificationSound.default()
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 3 , repeats: false)
            let request = UNNotificationRequest(identifier: "timerDone", content: content, trigger: trigger)
            UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
            let systemSoundID: SystemSoundID = 1005
            //https://github.com/TUNER88/iOSSystemSoundsLibrary
            AudioServicesPlayAlertSound(systemSoundID)
        } else {
            // Fallback on earlier versions
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
