//
//  ViewController.swift
//  Project2-version 2
//
//  Created by Jianqiang Zhang on 30/9/17.
//  Copyright © 2017 Jianqiang Zhang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var txtEmailAddress: UITextField!
    @IBOutlet var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

